package DAO;

public class EnderecoDAO {

}
