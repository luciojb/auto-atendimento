package DAO;

import DTO.PessoaDTO;
import generic.GenericDAO;

public class PessoaDAO extends GenericDAO<PessoaDTO>{
	public PessoaDAO(){
		super(PessoaDAO.class);
	}
}
