package DAO;

import DTO.CompraDTO;
import generic.GenericDAO;

public class CompraDAO extends GenericDAO<CompraDTO>{
	public CompraDAO() {
		super(CompraDTO.class);
	}
}
