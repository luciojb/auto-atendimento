package DAO;

import DTO.EnderecoDTO;
import generic.GenericDAO;

public class EnderecoDAO extends GenericDAO<EnderecoDTO>{
	public EnderecoDAO() {
		super(EnderecoDTO.class);
	}
}
