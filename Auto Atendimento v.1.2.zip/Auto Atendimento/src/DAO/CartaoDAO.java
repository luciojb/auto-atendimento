package DAO;

import DTO.CartaoDTO;
import generic.GenericDAO;

public class CartaoDAO extends GenericDAO<CartaoDTO>{
	public CartaoDAO() {
		super(CartaoDTO.class);
	}
}
